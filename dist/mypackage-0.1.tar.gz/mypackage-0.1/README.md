# mypackage
This library was created as an example of how to publish my own Python package.

## Building this package locally
'python setup.py sdist'

## Installing this pacakge from GitHup
'pip install git+https://github.com/bokeimei/mypackage.git'

## Updating this package on GitHup
'pip install --upgrade git+https://github.com/bokeimei/mypackage.git'
